package com.company.infernoInfinity.commands.contracts;

public interface Executable {
    String execute();
}
