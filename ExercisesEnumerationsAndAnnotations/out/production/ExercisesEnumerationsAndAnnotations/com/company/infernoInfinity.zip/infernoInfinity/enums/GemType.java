package com.company.infernoInfinity.enums;

public enum GemType {
    RUBY,
    EMERALD,
    AMETHYST
}
