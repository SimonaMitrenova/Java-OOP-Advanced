package com.company.infernoInfinity.enums;

public enum WeaponType {
    AXE,
    SWORD,
    KNIFE
}
