package com.company.infernoInfinity.gems.contracts;

public interface Gem {
    int getBonusStrength();
    int getBonusAgility();
    int getBonusVitality();
}
