package com.company.infernoInfinity.io.contracts;


public interface Writer {
    void write(Object message);
}
